<?php

header("location: public/");
exit;